package modernartui.com.modernartui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

/**
 * Created by benjaminsilamutuku on 6/7/15.
 */
public class MoreInfoDialogFragment extends DialogFragment {
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.moreinfo, null);
        builder.setView(view);

        builder.setNegativeButton(R.string.not_now, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User cancelled the dialog
                Log.i("Information Dialog", "User cancelled the Dialog");
            }
        });

        builder.setPositiveButton(R.string.visit, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.i("Information Dialog", "Visit MOMA");
                Intent openBrowser = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.moma.org"));
                startActivity(openBrowser);
            }
        });

        return builder.create();
    }
}
